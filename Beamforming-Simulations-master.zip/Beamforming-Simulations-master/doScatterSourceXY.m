hold on; 
scatter(source_info(:,1), source_info(:,2), ...
    'kx', 'LineWidth', 1.5); 
hold off;