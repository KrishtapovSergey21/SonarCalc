# Beamforming-Simulations
Basic beamforming simulations for various circumstances (requires the acoustic beamforming files)

These contains various examples and experiments concerning beamforming. Files always start with 'Main...'.
Each script calls on function found in 'Acoustic-Beamforming' repository, hence the addpath('.\Program Files') for which it assumes the files to be located in.
