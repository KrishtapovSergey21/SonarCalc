.. _examples:

Examples
========

A gallery of showcase examples suitable for first-time and advanced users.
