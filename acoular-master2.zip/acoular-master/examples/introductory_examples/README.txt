Introductory examples
---------------------

Examples suitable for first-time users and beginners.
