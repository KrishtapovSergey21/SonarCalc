Moving sources examples
-----------------------

Examples show the generation of synthetic data with moving sources and the application of advanced microphone array methods with moving (and fixed) focus.
