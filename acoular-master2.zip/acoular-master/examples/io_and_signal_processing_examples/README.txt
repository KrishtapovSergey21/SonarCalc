IO and signal processing examples
---------------------------------

Examples suitable for users who are familiar with the basics of Acoular and want to learn more about signal processing and input/output capabilities.
