#!/bin/bash

python -c "import acoular; print(acoular.__version__); acoular.demo.run()"
