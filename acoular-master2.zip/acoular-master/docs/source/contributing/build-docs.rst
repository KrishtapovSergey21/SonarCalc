Documentation Compilation
~~~~~~~~~~~~~~~~~~~~~~~~~

The package documentation is provided under ``acoular/docs/source``. This directory contains the ``index.rst`` file, which is the root document embedding several other subdocuments (sub-pages).

You can check that the documentation can be compiled without errors locally by running:

.. include:: ../commands/build-docs.rst
