``{{ name }}``
{{ underline }}

.. currentmodule:: {{ module }}

.. autoattribute:: {{ fullname }}
   :no-index:
