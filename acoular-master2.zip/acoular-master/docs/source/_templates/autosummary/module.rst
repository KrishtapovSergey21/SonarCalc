``{{ name }}``
{{ underline }}

.. automodule:: {{fullname}}

