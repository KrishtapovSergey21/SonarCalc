``{{ name }}``
{{ underline }}

.. currentmodule:: {{ module }}

.. auto{{ objtype }}:: {{ fullname }}
   :no-index:
