.. -*- mode: rst -*-

People
------

- `Jean Kossaifi <http://jeankossaifi.com>`_
- `Yannis Panagakis <http://ibug.doc.ic.ac.uk/people/ypanagakis>`_
- `Anima Anandkumar <http://www.eas.caltech.edu/people/anima>`_
- `Maja Pantic <http://ibug.doc.ic.ac.uk/people/mpantic>`_
