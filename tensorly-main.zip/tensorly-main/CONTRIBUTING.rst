========================
Contributing to TensorLy
========================

We welcome contributions. Please read the contribution guide in the repository at doc/development_guide/contributing.rst,
or online at http://tensorly.org/stable/development_guide/contributing.html.
