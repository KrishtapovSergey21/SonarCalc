.. raw:: html

   <script type="text/javascript">
   window.location.href = "index.html"
   </script>
