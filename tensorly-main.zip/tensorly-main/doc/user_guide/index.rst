.. _user_guide:

User guide
==========

.. toctree::
   :numbered:

   quickstart.rst
   backend.rst
   tensor_basics.rst
   tensor_decomposition.rst
   tensor_regression.rst
   sparse_backend.rst
