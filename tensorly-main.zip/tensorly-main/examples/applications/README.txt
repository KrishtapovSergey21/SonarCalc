Practical applications of tensor methods
----------------------------------------

See how you can use TensorLy on practical applications and datasets.
