Tensor decomposition
--------------------

