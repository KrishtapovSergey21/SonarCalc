# 0.4.0

- Added TensorFlow backend with Eager execution
- Added CuPy backend
- PyTorch backend updated for PyTorch >= '0.4.0'

# 0.3.0

- Added PyTorch backend

# 0.2.0

- Added MXNet backend

# 0.1.4

- Added Robust Tensor PCA
