"""A module for experimental functions

    Allows to add quickly and test new functions for which the API is not necessarily fixed
"""
