from .base import random_tensor
from .base import (
    random_cp,
    random_tucker,
    random_tr,
    random_tt,
    random_tt_matrix,
    random_parafac2,
)
