from .deprecation import deprecated, DefineDeprecated
