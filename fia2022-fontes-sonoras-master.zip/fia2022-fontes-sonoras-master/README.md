
Repositório com os códigos desenvolvidos para o trabalho `Toolbox educacional para simulação de fontes sonoras estáticas e em movimento`, apresentado no evento FIA 2022.

[Instruções para uso](https://www.researchgate.net/publication/364195083_Toolbox_educacional_para_simulacao_de_fontes_sonoras_estaticas_e_em_movimento) 
