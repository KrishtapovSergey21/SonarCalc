function r = defaultc0()
    r = 343.3;
end