function setGlobalc0(val)
global x
x = val;
end