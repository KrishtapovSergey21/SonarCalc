.. doatools documentation master file, created by sphinx-quickstart

Welcome to doatools's documentation!
====================================

.. toctree::
   :maxdepth: 2
   
   references/doatools.model
   references/doatools.estimation
   references/doatools.performance
   references/doatools.plotting
   references/doatools.misc

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
