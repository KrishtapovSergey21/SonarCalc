Mean-squared errors
===================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.performance.mse
    :members:
