Collecting snapshots
====================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.model.snapshots
    :members:
