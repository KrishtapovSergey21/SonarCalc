Visualize arrays
================

API reference
~~~~~~~~~~~~~

.. automodule:: doatools.plotting.plot_array
    :members:
