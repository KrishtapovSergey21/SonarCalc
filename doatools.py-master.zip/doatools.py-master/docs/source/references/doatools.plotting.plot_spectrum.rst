Visualize spectrum outputs
==========================

API reference
~~~~~~~~~~~~~

.. automodule:: doatools.plotting.plot_spectrum
    :members:
