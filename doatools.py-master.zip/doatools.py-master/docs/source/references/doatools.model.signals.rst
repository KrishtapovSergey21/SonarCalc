Modeling source signals
=======================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.model.signals
    :members:
