Modeling array perturbations
============================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.model.perturbations
    :members:
