Cramér-Rao bounds
=================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.performance.crb
    :members:
