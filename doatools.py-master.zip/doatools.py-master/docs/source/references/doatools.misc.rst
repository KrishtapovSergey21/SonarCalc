Miscellaneous
=============

.. toctree::
    :maxdepth: 1

    doatools.optim.l1lsq
