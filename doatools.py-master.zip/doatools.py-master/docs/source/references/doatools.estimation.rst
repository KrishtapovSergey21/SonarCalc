Estimation
==========

.. toctree::
    :maxdepth: 1

    doatools.estimation.grid
    doatools.estimation.preprocessing
    doatools.estimation.source_number
    doatools.estimation.beamforming
    doatools.estimation.music
    doatools.estimation.min_norm
    doatools.estimation.esprit
    doatools.estimation.sparse
    doatools.estimation.ml
    doatools.estimation.coarray
