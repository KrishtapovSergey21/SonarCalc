Plotting
========

.. toctree::
    :maxdepth: 1

    doatools.plotting.plot_spectrum
    doatools.plotting.plot_array
