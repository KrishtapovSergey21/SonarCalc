Source number detection
=======================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.estimation.source_number
    :members:
