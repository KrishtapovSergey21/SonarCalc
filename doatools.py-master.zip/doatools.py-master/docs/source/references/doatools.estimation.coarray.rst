Augmented covariance matrices for difference coarrays
=====================================================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.estimation.coarray
    :members:
    :special-members: __call__
