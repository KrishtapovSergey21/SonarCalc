Solving least squares problems with sparse regularization
=========================================================

API references:
~~~~~~~~~~~~~~~

.. automodule:: doatools.optim.l1lsq
    :members:
