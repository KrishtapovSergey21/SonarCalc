Difference coarrays
===================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.model.coarray
    :members:
    :special-members: __call__
