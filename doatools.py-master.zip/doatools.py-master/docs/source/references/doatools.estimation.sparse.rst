Sparsity-based estimators
=========================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.estimation.sparse
    :members:
