Beamforming based estimators
============================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.estimation.beamforming
    :members:
