Modeling
========

.. toctree::
    :maxdepth: 1
    
    doatools.model.arrays
    doatools.model.array_elements
    doatools.model.perturbations
    doatools.model.sources
    doatools.model.signals
    doatools.model.snapshots
    doatools.model.coarray
