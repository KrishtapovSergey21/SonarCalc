Performance analysis
====================

.. toctree::
    :maxdepth: 1

    doatools.performance.mse
    doatools.performance.crb
