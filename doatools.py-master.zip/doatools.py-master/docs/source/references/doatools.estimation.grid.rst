Creating search grids
=====================

API references
~~~~~~~~~~~~~~

.. automodule:: doatools.estimation.grid
    :members:
