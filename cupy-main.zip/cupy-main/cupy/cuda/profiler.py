# For backward compatibility only.
from __future__ import annotations

from cupy_backends.cuda.api.runtime import profilerStart as start  # noqa
from cupy_backends.cuda.api.runtime import profilerStop as stop  # noqa
