from __future__ import annotations

__version__ = '15.0.0a1'
