#include <thrust/detail/config/namespace.h>
