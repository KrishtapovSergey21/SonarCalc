These files are copied from thrust project and are modified.

    http://thrust.github.io/