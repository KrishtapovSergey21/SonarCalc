from cupyx.signal._convolution._convolve import convolve1d2o  # NOQA
from cupyx.signal._convolution._convolve import convolve1d3o  # NOQA
