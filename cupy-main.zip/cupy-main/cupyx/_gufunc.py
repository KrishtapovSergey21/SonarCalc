from __future__ import annotations

import cupy


class GeneralizedUFunc(cupy._core._gufuncs._GUFunc):
    __doc__ = cupy._core._gufuncs._GUFunc.__doc__
