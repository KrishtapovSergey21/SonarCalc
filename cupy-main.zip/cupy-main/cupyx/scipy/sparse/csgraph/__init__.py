# Functions from the following SciPy document
# https://docs.scipy.org/doc/scipy/reference/sparse.csgraph.html
from __future__ import annotations


from cupyx.scipy.sparse.csgraph._traversal import connected_components  # NOQA
