#ifndef INCLUDE_GUARD_CUDA_CUPY_CUSOLVER_H
#define INCLUDE_GUARD_CUDA_CUPY_CUSOLVER_H

#include <cuda.h>
#include <cusolverDn.h>
#include <cusolverSp.h>

#endif // #ifndef INCLUDE_GUARD_CUDA_CUPY_CUSOLVER_H
