#ifndef INCLUDE_GUARD_CUDA_CUPY_PROFILER_H
#define INCLUDE_GUARD_CUDA_CUPY_PROFILER_H

#include <cuda.h>
#include <cuda_profiler_api.h>

#endif // #ifndef INCLUDE_GUARD_CUDA_CUPY_PROFILER_H
