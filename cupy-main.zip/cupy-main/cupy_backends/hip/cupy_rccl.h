#ifndef INCLUDE_GUARD_HIP_CUPY_RCCL_H
#define INCLUDE_GUARD_HIP_CUPY_RCCL_H

#include <rccl.h>
typedef hipStream_t cudaStream_t;

#endif
