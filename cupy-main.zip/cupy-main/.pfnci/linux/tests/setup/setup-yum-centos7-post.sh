#!/bin/bash -uex

yum-config-manager --disable 'CentOS-7 - SCLo rh'
yum-config-manager --disable 'CentOS-7 - SCLo sclo'
