{{ fullname | escape | underline}}

.. automodule:: {{fullname}}
    :members: