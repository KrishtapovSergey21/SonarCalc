from vbeam.util.jax.grad import grad_for_argname

__all__ = ["grad_for_argname"]
