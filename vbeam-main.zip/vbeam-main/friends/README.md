This is a collection of projects that depend on vbeam and that may some day be moved to their own repositories. For now they are kept in the same repository as vbeam so that their co-development can be as seamless as possible. Besides, everything is nicer when in friendly company!

The projects here may also be used as inspiration for how to use vbeam in your own projects! You, too, are wanted as a friend of vbeam.

![vbeam friends logo](https://www.magnus.codes/vbeam/header_logo.svg)