#ifndef CONFIGURATIONLOADSAVE_H
#define CONFIGURATIONLOADSAVE_H

#include <QString>
#include <QFile>
#include <QTextStream>

#include "configurationVector.h"

class ConfigurationLoadSave
{

public:


    /***********************************************************
    * Constructor                                              *
    ***********************************************************/

    ConfigurationLoadSave();

    /***********************************************************
    * Destructor                                               *
    ***********************************************************/

    ~ConfigurationLoadSave();



};

#endif // CONFIGURATIONLOADSAVE_H
