from __future__ import annotations

from dask.bytes.core import read_bytes
