# Security Policy

## Reporting a Vulnerability

We use GitHub's security advisory workflow. To report a new vulnerability click [here](https://github.com/acoular/acoular/security/advisories/new).
These reports are private and only readable for project admins.
