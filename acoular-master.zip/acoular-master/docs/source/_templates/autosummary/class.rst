``{{ name }}``
{{ underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
    :no-index:
