``{{ name }}``
{{ underline }}

.. autofunction:: {{fullname}}
   :no-index:
