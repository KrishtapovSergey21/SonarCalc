``{{ name }}``
{{ underline }}

.. currentmodule:: {{ module }}

.. automethod:: {{ fullname }}
   :no-index:
