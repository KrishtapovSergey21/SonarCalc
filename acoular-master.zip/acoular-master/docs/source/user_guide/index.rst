User Guide
==========

This guide is an overview and explains important features of Acoular.

.. toctree::
   :maxdepth: 2

   get_started
