Reference Manual
================

Modules in Acoular
------------------
The following modules are part of Acoular:

.. currentmodule:: acoular 

.. autosummary::
    :toctree: generated/
    :recursive:

    aiaa
    base
    calib
    configuration
    demo
    deprecation
    environments
    fbeamform
    fprocess
    grids
    microphones
    process
    sdinput
    signals
    sources
    spectra
    tbeamform
    tools
    tprocess
    trajectory


