.. include:: ../../../CONTRIBUTING.rst

.. _Contribution Guidelines:

Contribution Guidelines
-----------------------

.. toctree:: 
    :maxdepth: 2

    install.rst
    quality.rst
    documentation.rst
    release.rst
    deprecation.rst
    pull_request.rst
    checklist.rst

