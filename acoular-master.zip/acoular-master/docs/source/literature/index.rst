Literature
==========

The following references give some theoretical background about the methods being used in the Acoular program package.

.. bibliography::
