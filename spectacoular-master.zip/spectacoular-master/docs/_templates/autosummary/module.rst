{{ name }}
{{ underline }}

.. automodule:: {{fullname}}

