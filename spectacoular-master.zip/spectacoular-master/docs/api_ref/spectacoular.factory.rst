﻿factory
====================

.. automodule:: spectacoular.factory
