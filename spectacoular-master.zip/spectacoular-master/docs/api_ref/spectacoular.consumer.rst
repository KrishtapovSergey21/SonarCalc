﻿consumer
=====================

.. automodule:: spectacoular.consumer
