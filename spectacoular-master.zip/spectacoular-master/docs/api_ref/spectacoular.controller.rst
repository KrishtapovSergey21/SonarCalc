﻿controller
=======================

.. automodule:: spectacoular.controller
