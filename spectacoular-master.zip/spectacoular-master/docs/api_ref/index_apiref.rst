Reference Manual
================

The following modules are part of SpectAcoular:

.. currentmodule:: spectacoular 

.. autosummary::
   :toctree:

    bokehview
    factory
    consumer
    lprocess
    dprocess
    controller


