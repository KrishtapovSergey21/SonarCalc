.. _examples:

Examples
========

A gallery of showcases on how to build interactive applications with SpectAcoular.
