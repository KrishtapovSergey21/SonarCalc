.. AUTHORS.rst

History
=======

This project was started in 2020 by the Acoular Development Team. It is published under an open source license (BSD).

People
======

* Ennes Sarradj
* Gert Herold
* Adam Kujawski
* Arne Hölter
* Simon Jekosch


