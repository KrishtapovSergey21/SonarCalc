#!/bin/bash
bokeh serve --port 5008 --show Measurement_App --args --device=phantom --blocksize=256
