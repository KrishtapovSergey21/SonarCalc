__author__ = 'Adam Kujawski, Art Pelling, Simon Jekosch, Can Kayser, Ennes Sarradj'
__date__ = 'April, 29, 2025'
__version__ = '25.05'
