"""The datasets subpackage contains default classes to create acoustical datasets with microphone array data."""
