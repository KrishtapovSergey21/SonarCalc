"""The AcouPipe module extends the computational pipeline-based concept of Acoular_ and provides additional tools that can be helpful to generate realizations of features in a predefined random process."""

__author__ = 'Adam Kujawski, Art R. J. Pelling, Simon Jekosch, Ennes Sarradj'
__version__ = '24.04'
