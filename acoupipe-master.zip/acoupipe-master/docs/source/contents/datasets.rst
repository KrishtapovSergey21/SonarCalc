.. _data:


Datasets
========

.. toctree::
    :maxdepth: 1

    datasets/quickstart
    Synthetic Datasets <../autoapi/acoupipe/datasets/synthetic/index>
    Experimental Datasets <../autoapi/acoupipe/datasets/experimental/index>
    datasets/features
    jupyter/modify


