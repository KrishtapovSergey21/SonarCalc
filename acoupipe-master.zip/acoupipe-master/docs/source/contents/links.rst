
.. Links:

.. _SLURM: https://slurm.schedmd.com/quickstart.html
.. _Singularity: https://sylabs.io/guides/3.0/user-guide/quick_start.html
.. _Ray: https://docs.ray.io/en/latest
.. _`Ray Cluster`: https://docs.ray.io/en/latest/cluster/getting-started.html
.. _Tensorflow: https://www.tensorflow.org/
.. _`Tensorflow Dataset API`: https://www.tensorflow.org/api_docs/python/tf/data/Dataset#from_generator
.. _TFRecord: https://www.tensorflow.org/tutorials/load_data/tfrecord
.. _Docker: https://www.docker.com/
.. _DockerHub: https://hub.docker.com/r/adku1173/acoupipe
.. _Acoular: http://www.acoular.org
.. _HDF5: https://support.hdfgroup.org/documentation/index.html
.. _Pandas: https://pandas.pydata.org/docs/
.. _h5py: https://docs.h5py.org/en/stable/
.. _tqdm: https://github.com/tqdm/tqdm
.. _NumPy: https://numpy.org/
.. _SciPy: https://www.scipy.org/
.. _matplotlib: https://matplotlib.org/
.. _MIRACLE: https://depositonce.tu-berlin.de/items/b079fd1c-999f-42cb-afd2-bcd34de6180b
.. _pooch: https://www.fatiando.org/pooch/latest/
