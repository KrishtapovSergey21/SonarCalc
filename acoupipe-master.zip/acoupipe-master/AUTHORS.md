# AcouPipe developers and contributors

## Main developers

* Adam Kujawski, @adku1173
* Simon Jekosch, @sjekosch
* Art Pelling, @artpelling

## Contributors
* Can Kayser, @knods3k

