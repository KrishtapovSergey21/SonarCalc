{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :no-special-members:
   :no-members:
   :no-inherited-members:
