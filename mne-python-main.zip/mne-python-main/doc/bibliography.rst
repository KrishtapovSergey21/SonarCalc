:orphan:

.. _general_bibliography:

General bibliography
====================

The references below are arranged alphabetically by first author.

.. bibliography:: ./references.bib
   :all:
   :list: enumerated
