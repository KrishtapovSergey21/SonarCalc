
Creating data objects from arrays
=================================

.. currentmodule:: mne

.. autosummary::
   :toctree: ../generated/

   EvokedArray
   EpochsArray
   io.RawArray
   create_info
