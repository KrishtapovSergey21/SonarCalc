
MNE-Report
==========

:py:mod:`mne`:

.. currentmodule:: mne

.. autosummary::
   :toctree: ../generated/

   Report
   open_report
