Most-used classes
=================

.. currentmodule:: mne

.. autosummary::
   :toctree: ../generated/

   io.Raw
   Epochs
   Evoked
   Info
