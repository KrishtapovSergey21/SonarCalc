
Connectivity Estimation
=======================

As of 0.24, connectivity functionality has been moved to the separate package
:mod:`mne-connectivity:mne_connectivity`.
