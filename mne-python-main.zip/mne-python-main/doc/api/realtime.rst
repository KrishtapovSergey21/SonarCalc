.. include:: ../links.inc

Realtime
========

Realtime functionality has moved to the standalone module `MNE-LSL`_.
