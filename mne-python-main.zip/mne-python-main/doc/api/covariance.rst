
Covariance computation
======================

.. currentmodule:: mne

.. autosummary::
   :toctree: ../generated/

   Covariance
   compute_covariance
   compute_raw_covariance
   cov.compute_whitener
   cov.prepare_noise_cov
   cov.regularize
   compute_rank
   make_ad_hoc_cov
   read_cov
   write_cov
