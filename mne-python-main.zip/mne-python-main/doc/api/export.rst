
Exporting
================

:py:mod:`mne.export`:

.. automodule:: mne.export
   :no-members:
   :no-inherited-members:

.. currentmodule:: mne.export

.. autosummary::
   :toctree: ../generated/

   export_epochs
   export_evokeds
   export_evokeds_mff
   export_raw
