:orphan:

.. _contributors:

============
Contributors
============

There are many different ways to contribute to MNE-Python! So far we only list
code contributions below, but plan to add other metrics in the future.

.. include:: ./code_credit.inc
