.. See doc/development/contributing.rst for description of how to add entries.

.. _current:

.. towncrier-draft-entries:: Version |release| (development)
