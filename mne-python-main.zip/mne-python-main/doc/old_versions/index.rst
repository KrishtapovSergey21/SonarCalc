Archived documentation for old versions
=======================================

.. compressed with: zip -r -s 100m 0.20.zip 0.20/

Zip archives of old documentation versions are available below. Some have
multiple parts because GitHub has a 100 MB file size limit.

- `v0.20 part 1 <https://mne.tools/0.20.zip>`__ and `part 2 <https://mne.tools/0.20.z01>`__
- `v0.19 part 1 <https://mne.tools/0.19.zip>`__ and `part 2 <https://mne.tools/0.19.z01>`__
- `v0.18 <https://mne.tools/0.18.zip>`__
- `v0.17 <https://mne.tools/0.17.zip>`__
- `v0.16 <https://mne.tools/0.16.zip>`__
- `v0.15 <https://mne.tools/0.15.zip>`__
- `v0.14 <https://mne.tools/0.14.zip>`__
- `v0.13 <https://mne.tools/0.13.zip>`__
- `v0.12 <https://mne.tools/0.12.zip>`__
- `v0.11 <https://mne.tools/0.11.zip>`__
