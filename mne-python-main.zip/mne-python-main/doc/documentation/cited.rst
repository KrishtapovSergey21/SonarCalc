.. _cited:

Papers citing MNE-Python
========================

Estimates provided by Google Scholar as of 16 December 2024:

- `MNE (2,190) <https://scholar.google.com/scholar?cites=12188330066413208874&as_ylo=2014>`_
- `MNE-Python (4,360) <https://scholar.google.com/scholar?cites=1521584321377182930&as_ylo=2013>`_
