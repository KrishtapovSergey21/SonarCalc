# Beamforming-for-speech-enhancement
- simple delaysum, MVDR and CGMM-MVDR
- Please run *_test.py, and youw will get enhancement speech in /output directory

