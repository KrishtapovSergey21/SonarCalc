# Acoutic Source localisation using MUSIC DOA algorithm
This is an implementation of **MUSIC**(MUlti-Signal Classifier) **DOA**(Direction of arrival) algorithm. This C package is used for acoutic source localisation of AUV using hydrophones. 
## Author:
[Varun Pawar](mailto:varunpwr897@gmail.com)
