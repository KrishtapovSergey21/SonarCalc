#ifndef __MUSIC_H_
#define __MUSIC_H__

/*Sorts an integer array. Takes a pointer to the first element and the length of the array as input.
Returns 0 on successful sort.*/
float* give_heading(float*,int);
int zero_array(float* Arr);
float** EofArray(float**,int,int);

#endif
