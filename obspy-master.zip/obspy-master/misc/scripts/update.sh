#!/bin/bash
easy_install -N -U https://github.com/obspy/obspy/tarball/master
