#!/bin/bash
pip install --upgrade --no-deps git+https://github.com/obspy/obspy.git
