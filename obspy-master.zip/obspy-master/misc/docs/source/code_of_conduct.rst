.. _code_of_conduct:

.. mdinclude:: ../../../CODE_OF_CONDUCT.md
