.. currentmodule:: obspy.io.focmec
.. automodule:: obspy.io.focmec

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
