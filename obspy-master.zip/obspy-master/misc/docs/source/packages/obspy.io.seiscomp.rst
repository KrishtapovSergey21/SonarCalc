.. currentmodule:: obspy.io.seiscomp
.. automodule:: obspy.io.seiscomp

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       event
       inventory

    .. comment to end block
