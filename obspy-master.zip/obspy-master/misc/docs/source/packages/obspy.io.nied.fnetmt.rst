.. currentmodule:: obspy.io.nied.fnetmt
.. automodule:: obspy.io.nied.fnetmt
    :noindex: