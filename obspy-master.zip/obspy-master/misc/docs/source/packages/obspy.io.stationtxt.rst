.. currentmodule:: obspy.io.stationtxt
.. automodule:: obspy.io.stationtxt

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
