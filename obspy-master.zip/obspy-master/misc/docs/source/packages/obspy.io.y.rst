.. currentmodule:: obspy.io.y
.. automodule:: obspy.io.y

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
