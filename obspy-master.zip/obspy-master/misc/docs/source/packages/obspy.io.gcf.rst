.. currentmodule:: obspy.io.gcf
.. automodule:: obspy.io.gcf

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
