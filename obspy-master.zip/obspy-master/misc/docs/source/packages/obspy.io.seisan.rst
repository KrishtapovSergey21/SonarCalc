.. currentmodule:: obspy.io.seisan
.. automodule:: obspy.io.seisan

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
