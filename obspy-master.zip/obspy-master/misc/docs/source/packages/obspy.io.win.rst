.. currentmodule:: obspy.io.win
.. automodule:: obspy.io.win

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
