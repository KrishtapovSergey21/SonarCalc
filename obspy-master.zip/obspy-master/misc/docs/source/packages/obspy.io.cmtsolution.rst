.. currentmodule:: obspy.io.cmtsolution
.. automodule:: obspy.io.cmtsolution

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
