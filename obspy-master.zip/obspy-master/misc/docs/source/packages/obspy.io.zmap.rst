.. currentmodule:: obspy.io.zmap
.. automodule:: obspy.io.zmap

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
