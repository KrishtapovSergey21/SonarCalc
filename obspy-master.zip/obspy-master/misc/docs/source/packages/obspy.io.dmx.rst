.. currentmodule:: obspy.io.dmx
.. automodule:: obspy.io.dmx

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
