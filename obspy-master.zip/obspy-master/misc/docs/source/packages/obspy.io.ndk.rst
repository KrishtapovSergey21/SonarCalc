.. currentmodule:: obspy.io.ndk
.. automodule:: obspy.io.ndk

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
