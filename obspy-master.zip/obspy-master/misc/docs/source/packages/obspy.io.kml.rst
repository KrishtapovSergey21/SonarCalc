.. currentmodule:: obspy.io.kml
.. automodule:: obspy.io.kml

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
