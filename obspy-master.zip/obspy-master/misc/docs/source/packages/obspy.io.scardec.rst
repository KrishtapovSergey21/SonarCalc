.. currentmodule:: obspy.io.scardec
.. automodule:: obspy.io.scardec

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
