.. currentmodule:: obspy.io.seg2
.. automodule:: obspy.io.seg2

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       seg2

    .. comment to end block
