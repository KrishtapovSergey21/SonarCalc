.. currentmodule:: obspy.clients.syngine
.. automodule:: obspy.clients.syngine

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       client.Client

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       client

    .. comment to end block
