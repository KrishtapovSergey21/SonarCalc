.. currentmodule:: obspy.io.sh
.. automodule:: obspy.io.sh

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       evt

    .. comment to end block
