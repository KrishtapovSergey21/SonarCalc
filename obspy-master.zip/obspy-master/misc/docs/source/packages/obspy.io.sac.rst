.. currentmodule:: obspy.io.sac
.. automodule:: obspy.io.sac

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       sacpz
       header
       arrayio
       sactrace
       util

    .. comment to end block
