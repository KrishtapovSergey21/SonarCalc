.. currentmodule:: obspy.io.alsep
.. automodule:: obspy.io.alsep

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       assign
       core
       define
       util

    .. comment to end block
