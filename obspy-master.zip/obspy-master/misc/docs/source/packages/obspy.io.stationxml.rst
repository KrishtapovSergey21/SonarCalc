.. currentmodule:: obspy.io.stationxml
.. automodule:: obspy.io.stationxml

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
