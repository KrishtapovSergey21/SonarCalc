.. currentmodule:: obspy.io.nied.knet
.. automodule:: obspy.io.nied.knet
    :noindex: