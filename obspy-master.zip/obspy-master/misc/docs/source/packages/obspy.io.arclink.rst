.. currentmodule:: obspy.io.arclink
.. automodule:: obspy.io.arclink

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       inventory

    .. comment to end block
