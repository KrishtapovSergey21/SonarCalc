.. currentmodule:: obspy.io.ah
.. automodule:: obspy.io.ah

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
