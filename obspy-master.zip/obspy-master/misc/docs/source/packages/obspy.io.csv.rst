.. currentmodule:: obspy.io.csv
.. automodule:: obspy.io.csv

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
