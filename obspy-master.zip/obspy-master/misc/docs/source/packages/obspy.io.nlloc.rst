.. currentmodule:: obspy.io.nlloc
.. automodule:: obspy.io.nlloc

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       util

    .. comment to end block
