.. currentmodule:: obspy.io.iaspei
.. automodule:: obspy.io.iaspei

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
