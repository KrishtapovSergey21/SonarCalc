.. currentmodule:: obspy.io.cybershake
.. automodule:: obspy.io.cybershake

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
