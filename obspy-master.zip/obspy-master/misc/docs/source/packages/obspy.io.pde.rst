.. currentmodule:: obspy.io.pde
.. automodule:: obspy.io.pde

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       mchedr

    .. comment to end block
