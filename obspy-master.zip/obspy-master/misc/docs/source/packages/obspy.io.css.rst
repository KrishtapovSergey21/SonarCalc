.. currentmodule:: obspy.io.css
.. automodule:: obspy.io.css

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       station

    .. comment to end block
