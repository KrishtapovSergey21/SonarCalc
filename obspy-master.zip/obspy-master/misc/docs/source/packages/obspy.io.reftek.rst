.. currentmodule:: obspy.io.reftek
.. automodule:: obspy.io.reftek

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       util
       packet

    .. comment to end block
