.. currentmodule:: obspy.io.cnv
.. automodule:: obspy.io.cnv

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
