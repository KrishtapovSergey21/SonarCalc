.. currentmodule:: obspy.io.json
.. automodule:: obspy.io.json

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       ~core.get_dump_kwargs
       ~core._write_json
       ~default.Default

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       default

    .. comment to end block

