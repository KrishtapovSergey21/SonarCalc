.. currentmodule:: obspy.io.pdas
.. automodule:: obspy.io.pdas

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
