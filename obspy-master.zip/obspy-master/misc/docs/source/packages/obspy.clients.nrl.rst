.. currentmodule:: obspy.clients.nrl
.. automodule:: obspy.clients.nrl

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       client.NRL

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       client

    .. comment to end block

    Scripts
    -------
    .. autosummary::
       :template: script.rst
       :toctree: autogen
       :nosignatures:


    .. comment to end block
