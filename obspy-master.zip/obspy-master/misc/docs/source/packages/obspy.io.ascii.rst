.. currentmodule:: obspy.io.ascii
.. automodule:: obspy.io.ascii

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
