.. currentmodule:: obspy.io.mseed
.. automodule:: obspy.io.mseed

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       util

    .. comment to end block

    Scripts
    -------
    .. autosummary::
      :template: script.rst
      :toctree: autogen
      :nosignatures:

        scripts.recordanalyzer

    .. comment to end block
