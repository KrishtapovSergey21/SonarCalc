.. currentmodule:: obspy.realtime
.. automodule:: obspy.realtime

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       rttrace
       rtmemory
       signal

    .. comment to end block