.. currentmodule:: obspy.io.kinemetrics
.. automodule:: obspy.io.kinemetrics

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
