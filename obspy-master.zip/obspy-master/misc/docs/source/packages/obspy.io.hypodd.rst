.. currentmodule:: obspy.io.hypodd
.. automodule:: obspy.io.hypodd

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       pha

    .. comment to end block
