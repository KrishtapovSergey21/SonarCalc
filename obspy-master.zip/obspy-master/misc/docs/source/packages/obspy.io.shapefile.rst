.. currentmodule:: obspy.io.shapefile
.. automodule:: obspy.io.shapefile

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core

    .. comment to end block
