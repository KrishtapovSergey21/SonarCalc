.. currentmodule:: obspy.io.rg16
.. automodule:: obspy.io.rg16

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       core
       util

    .. comment to end block
