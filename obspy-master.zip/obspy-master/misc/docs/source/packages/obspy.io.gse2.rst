.. currentmodule:: obspy.io.gse2
.. automodule:: obspy.io.gse2

    .. comment to end block

    Modules
    -------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       bulletin
       core
       libgse2
       libgse1
       paz

    .. comment to end block
