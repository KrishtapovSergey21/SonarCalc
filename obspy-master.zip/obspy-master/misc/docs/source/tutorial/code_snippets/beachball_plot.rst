==============
Beachball Plot
==============

The following lines show how to create a graphical representation of a
focal mechanism.

.. plot:: tutorial/code_snippets/beachball_plot.py
   :include-source:
