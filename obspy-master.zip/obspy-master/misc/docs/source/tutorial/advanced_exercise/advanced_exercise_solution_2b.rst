Advanced Exercise Solution 2b
-----------------------------

.. include:: advanced_exercise_solution_2b.py
   :literal:
