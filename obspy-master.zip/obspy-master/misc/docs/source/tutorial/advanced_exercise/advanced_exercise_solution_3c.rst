Advanced Exercise Solution 3c
-----------------------------

.. include:: advanced_exercise_solution_3c.py
   :literal:
