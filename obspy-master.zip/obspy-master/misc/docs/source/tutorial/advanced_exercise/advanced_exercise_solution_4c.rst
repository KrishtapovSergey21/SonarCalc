Advanced Exercise Solution 4c
-----------------------------

.. include:: advanced_exercise_solution_4c.py
   :literal:
