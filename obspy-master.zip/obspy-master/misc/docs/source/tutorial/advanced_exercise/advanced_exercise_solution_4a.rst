Advanced Exercise Solution 4a
-----------------------------

.. include:: advanced_exercise_solution_4a.py
   :literal:
