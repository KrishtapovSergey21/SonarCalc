Advanced Exercise Solution 5
----------------------------

.. include:: advanced_exercise_solution_5.py
   :literal:
