Advanced Exercise Solution 3a
-----------------------------

.. include:: advanced_exercise_solution_3a.py
   :literal:
