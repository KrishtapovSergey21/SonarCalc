Advanced Exercise Solution 1
----------------------------

.. include:: advanced_exercise_solution_1.py
   :literal:
