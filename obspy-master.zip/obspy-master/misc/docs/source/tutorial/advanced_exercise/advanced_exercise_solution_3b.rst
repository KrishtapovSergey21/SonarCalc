Advanced Exercise Solution 3b
-----------------------------

.. include:: advanced_exercise_solution_3b.py
   :literal:
