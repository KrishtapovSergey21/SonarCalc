Advanced Exercise Solution 2a
-----------------------------

.. include:: advanced_exercise_solution_2a.py
   :literal:
