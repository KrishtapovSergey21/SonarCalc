Advanced Exercise Solution 4b
-----------------------------

.. include:: advanced_exercise_solution_4b.py
   :literal:
