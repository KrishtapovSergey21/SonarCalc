.. _skdh-gait_old:

.. automodule:: skdh.gait_old
    :ignore-module-all:
