.. _skdh-gait:

.. automodule:: skdh.gait
    :ignore-module-all:
