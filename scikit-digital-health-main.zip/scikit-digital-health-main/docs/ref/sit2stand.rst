.. _skdh-sit2stand:

.. automodule:: skdh.sit2stand
    :ignore-module-all:
