{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :no-inherited-members:
   :no-special-members:
   :no-undoc-members:
   :no-private-members:
