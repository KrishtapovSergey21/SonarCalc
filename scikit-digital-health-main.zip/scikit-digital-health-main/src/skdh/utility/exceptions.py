class LowFrequencyError(Exception):
    pass


class FileSizeError(Exception):
    pass
